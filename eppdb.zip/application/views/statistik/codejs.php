<!-- chart -->
<script src="<?= base_url();?>assets/bower_components/chart.js/Chart.js"></script>

<script type="text/javascript">

</script>     