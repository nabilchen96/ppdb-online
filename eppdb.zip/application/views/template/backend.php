<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/footer'); ?>