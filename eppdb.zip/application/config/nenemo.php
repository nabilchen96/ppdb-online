<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['sitename'] = '<i class="fab fa-gg"></i> e-PPDB';
$config['sitename_mini'] = '<i class="fab fa-gg"></i>';
$config['title'] = 'e-PPDB';
$config['botton'] = 'btn btn-success btn-flat';
$config['header'] = 'bg-blue';
// ====> mohon jangan di ganti
$config['tahun'] = '2020';
$config['copyright'] = 'Nenemo Project';
// ====> dev
$config['developer'] = 'Hairul Azmi';
$config['email'] = 'ilung82@gmail.com';
$config['contact'] = '082184032134';
$config['workplace'] = 'SMP Negeri 1 Tumijajar';
$config['project'] = 'e-PPDB';
$config['codename'] = 'Raya';
$config['version'] = '1.5.3';
$config['license'] = '...';
