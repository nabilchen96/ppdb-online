$(function(){
	$('.image-thumbnail').fancybox();	
});	